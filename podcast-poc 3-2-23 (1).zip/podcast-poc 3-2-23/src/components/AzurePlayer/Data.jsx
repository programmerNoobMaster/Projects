const songs = [   
    {
      id :1,
      title: "Podcast 1",
      description : "Test Podcast 1",
      imgsrc:"https://cdn.pixabay.com/photo/2014/02/03/16/52/chain-257490__480.jpg",
      src: "https://dev1mediaservice.streaming.mediaservices.windows.net/5acf9393-5883-4d7b-8d68-c9a8b495ecd1/5ffb03fe-450e-40d6-88d9-e46e8dc8.ism/manifest",
      ShotClassUrl : "https://dev2learner.shotclasses.com/UnileverDevPodcast/home?authenticate=https%3a%2f%2fdev2learner.shotclasses.com%2fUnileverDevPodcast%23%2fmyTrainings%3fShotClassId%3d81400"
    },
    {
      id: 2,
      title: "Podcast 2",      
      description : "Test Podcast 2",
      imgsrc : "https://cdn.pixabay.com/photo/2016/11/29/12/13/fence-1869401__480.jpg",
      src: "https://dev1mediaservice.streaming.mediaservices.windows.net/4a805639-5a0f-4c45-b9f9-1dade22c74c7/cbef2bb0-54b8-4dc7-b8e9-e0ba5e1b.ism/manifest",
      ShotClassUrl : "https://dev2learner.shotclasses.com/UnileverDevPodcast/home?authenticate=https%3a%2f%2fdev2learner.shotclasses.com%2fUnileverDevPodcast%23%2fmyTrainings%3fShotClassId%3d81399"
      
    },
    {
      id: 3,
      title: "Podcast 3",
      description : "Test Podcast 3",
      imgsrc:"https://cdn.pixabay.com/photo/2017/08/24/11/04/brain-2676370__480.jpg",
      src: "https://dev1mediaservice.streaming.mediaservices.windows.net/fe6c211e-9998-44d8-9a3a-3f76f1e87190/8ef1d825-89ce-456f-aae6-5bd7250c.ism/manifest",
      ShotClassUrl : "https://dev2learner.shotclasses.com/UnileverDevPodcast/home?authenticate=https%3a%2f%2fdev2learner.shotclasses.com%2fUnileverDevPodcast%23%2fmyTrainings%3fShotClassId%3d81405"
    },
  ];
  
  export default songs;

  