import React from "react";
import { Container } from "@mui/material";



export default function ExplorePodcasts() {
  return (
    <div className="section explore">
      <Container maxWidth="xl">
        <h3 className="section-heading">Explore Podcasts </h3>

        {/* <Grid className="grid" container spacing={2}>
          <Grid item xs={12} md={4}>
            <figure class="effect-goliath">
              <img src={podcast1} alt="img23" />
              <figcaption>
                <h2>
                  Sustainability <span>Brands</span>
                </h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                <a href="/PodcastList">View more</a>
              </figcaption>
            </figure>
          </Grid>
          <Grid item xs={12} md={4}>
            <figure class="effect-goliath">
              <img src={podcast2} alt="img23" />
              <figcaption>
                <h2>
                Sustainability <span>Brands</span>
                </h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                <a href="/PodcastList">View more</a>
              </figcaption>
            </figure>
          </Grid>
          <Grid item xs={12} md={4}>
            <figure class="effect-goliath">
              <img src={podcast3} alt="img23" />
              <figcaption>
                <h2>
                Sustainability <span>Brands</span>
                </h2>
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                <a href="/PodcastList">View more</a>
              </figcaption>
            </figure>
          </Grid> 
        </Grid>*/}
      </Container>
    </div>
  );
}
