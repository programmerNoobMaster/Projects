import React, { useState, useEffect, useRef } from "react";
import songs from "../AzurePlayer/Data";
import VolumeDownIcon from "@mui/icons-material/VolumeDown";
import VolumeUpIcon from "@mui/icons-material/VolumeUp";
import VolumeOffIcon from "@mui/icons-material/VolumeOff";
import VolumeMuteIcon from "@mui/icons-material/VolumeMute";
import PlayCircleIcon from "@mui/icons-material/PlayCircle";
import PauseCircleIcon from "@mui/icons-material/PauseCircle";
import FavoriteBorderIcon from "@mui/icons-material/FavoriteBorder";
import FavoriteIcon from "@mui/icons-material/Favorite";
import SkipNextIcon from "@mui/icons-material/SkipNext";
import SkipPreviousIcon from "@mui/icons-material/SkipPrevious";
import Forward30Icon from "@mui/icons-material/Forward30";
import Replay30Icon from "@mui/icons-material/Replay30";
import OpenInFullIcon from "@mui/icons-material/OpenInFull";
import ArrowCircleLeftOutlinedIcon from "@mui/icons-material/ArrowCircleLeftOutlined";

import SharePodcast from "../../components/AzurePlayer/SharePodcast";

export default function FixFooter() {
  const [slideUp, setSlideUp] = useState(false);

  let amp = window["amp"];
  const [isPlaying, setIsPlaying] = useState(false);
  const [songId, setSongId] = useState(0);
  const [speed, setSpeed] = useState(1);
  const [isLove, setLove] = useState(false);
  const [volume, setVolume] = useState(30);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [mute, setMute] = useState(false);
  const videoElement = useRef();
  const progressBar = useRef();
  const animationRef = useRef();

  const SkipSong = (forwards = true) => {
    if (forwards) {
      let temp = songId;
      temp++;
      if (temp > songs.length - 1) {
        temp = 0;
      }
      setSongId(temp);
      setIsPlaying(false);
      return temp;
    } else {
      let temp = songId;
      if (temp == 0) return;
      temp--;
      setSongId(temp);
      setIsPlaying(false);
      return temp;
    }
  };

  const backThirty = () => {
    const myPlayer = amp(videoElement?.current);
    var curTime = 0;
    curTime = myPlayer.currentTime() - 5;
    myPlayer.currentTime(curTime);
  };

  const FullScreen = () => {
    const myPlayer = amp(videoElement?.current);
    myPlayer.enterFullscreen();
  };

  const forwardThirty = () => {
    const myPlayer = amp(videoElement?.current);
    var curTime = 0;
    curTime = myPlayer.currentTime() + 5;
    myPlayer.currentTime(curTime);
  }; // const changeSpeed = () => { //  const myPlayer = amp(videoElement.current); //  if (speed >= 2) { //   setSpeed(0.5); //   myPlayer.playbackRate(speed); //  } else { //   setSpeed(speed + 0.5); //   myPlayer.playbackRate(speed); //  } // }; // useEffect(() => { //  if (videoElement.current){ //  const myPlayer = amp(videoElement.current); //  const seconds = Math.floor(myPlayer.duration()); //  console.log(seconds); //  setDuration(seconds); //  progressBar.current.max = seconds; //  } // }, [ //  videoElement?.current?.loadedmetadata, //  videoElement?.current?.readyState, // ]);

  const calculateTime = (secs) => {
    const minutes = Math.floor(secs / 60);
    const returnedMinutes = minutes < 10 ? `0${minutes}` : `${minutes}`;
    const seconds = Math.floor(secs % 60);
    const returnedSeconds = seconds < 10 ? `0${seconds}` : `${seconds}`;
    return `${returnedMinutes}:${returnedSeconds}`;
  };

  const ChangePlayPause = (e) => {
    e.stopPropagation();
    const myPlayer = amp(videoElement?.current);
    const prevValue = isPlaying;
    setIsPlaying(!prevValue);
    if (!prevValue) {
      myPlayer.play();
      animationRef.current = requestAnimationFrame(whilePlaying);
    } else {
      myPlayer.pause();
      cancelAnimationFrame(animationRef.current);
    }
  };

  const whilePlaying = () => {
    const myPlayer = amp(videoElement?.current);
    progressBar.current.value = myPlayer.currentTime();
    changePlayerCurrentTime();
    animationRef.current = requestAnimationFrame(whilePlaying);
  };

  const changeRange = () => {
    const myPlayer = amp(videoElement?.current);
    var curTime = 0;
    curTime = myPlayer.currentTime();
    curTime = progressBar.current.value;
    changePlayerCurrentTime();
  };

  const changePlayerCurrentTime = () => {
    progressBar.current.style.setProperty(
      "--seek-before-width",
      `${(progressBar.current.value / duration) * 100}%`
    );
    setCurrentTime(progressBar.current.value);
  };

  const chnageMute = () => {
    const myPlayer = amp(videoElement.current);
    const prevValue = mute;
    setMute(!prevValue);
    if (!prevValue) {
      myPlayer.muted(true);
    } else {
      myPlayer.muted(false);
    }
  };

  function VolumeBtns() {
    return mute ? (
      <VolumeOffIcon className="skip-btn" onClick={chnageMute} />
    ) : volume <= 20 ? (
      <VolumeMuteIcon className="skip-btn" onClick={chnageMute} />
    ) : volume <= 75 ? (
      <VolumeDownIcon className="skip-btn" onClick={chnageMute} />
    ) : (
      <VolumeUpIcon className="skip-btn" onClick={chnageMute} />
    );
  }

  const changeSongLove = (e) => {
    e.stopPropagation();
    setLove(!isLove);
  };

  useEffect(() => {
    const myPlayer = amp(videoElement.current);
    myPlayer.playbackRate(speed);
  }, [speed]);

  const changeSpeed = () => {
    if (speed >= 2) {
      setSpeed(0.5);
    } else {
      setSpeed(speed + 0.5);
    }
  };

  const myOptions = {
    nativeControlsForTouch: true,
    controls: true,
    autoplay: true,
    width: "640",
    height: "400",
    logo: { enabled: false },
    playbackSpeed: {
      enabled: true,
      initialSpeed: 1.0,
      speedLevels: [
        { name: "x4.0", value: 4.0 },
        { name: "x3.0", value: 3.0 },
        { name: "x2.0", value: 2.0 },
        { name: "x1.75", value: 1.75 },
        { name: "x1.5", value: 1.5 },
        { name: "x1.25", value: 1.25 },
        { name: "normal", value: 1.0 },
        { name: "x0.75", value: 0.75 },
        { name: "x0.5", value: 0.5 },
      ],
    },
  };

  useEffect(() => {
    if (videoElement?.current) {
      const myPlayer = amp(videoElement?.current, myOptions);
      myPlayer.src([
        {
          src: songs[songId].src,
          type: "application/vnd.ms-sstr+xml",
          ProtectionInfo: [
            {
              type: "AES", // authenticationToken: mediaToken?.Cotent,
            },
          ],
        },
      ]);
      setTimeout(() => {
        const seconds = Math.floor(myPlayer.duration());
        setDuration(seconds);
        progressBar.current.max = seconds;
      }, 500);
    }
  }, [videoElement, songId]);

  return (
    <div
      className={`fix-footer ${slideUp ? "active" : ""}`}
      onClick={() => {
        setSlideUp(true);
      }}
    >
      <div className="media-player">
        <div className={`${!slideUp && "displayNone"}`}>
          <div
            className="back-btn"
            onClick={(event) => {
              event.stopPropagation();
              setSlideUp(false);
            }}
          >
            <ArrowCircleLeftOutlinedIcon fontSize="large" />
          </div>
          <div className="embed-responsive embed-responsive-16by9">
            <video
              ref={videoElement}
              className="azuremediaplayer embed-responsive-item"
              tabIndex="0"
            ></video>
          </div>
        </div>

        <div className={` ${!slideUp && "footer-progress"}`}>
          <div className={`progress-bar ${!slideUp && "footer-progress-bar"}`}>
            <input
              type="range"
              className="progressBar"
              defaultValue="0"
              ref={progressBar}
              onChange={changeRange}
            />
          </div>

          {slideUp ? (
            <>
              <div className="player-control-bar">
                <div className="player-time d-flex">
                  <div className="start-time">
                    {" "}
                    {calculateTime(currentTime)} / &nbsp;{" "}
                  </div>
                  <div className="total-duration">
                    {" "}
                    {duration && !isNaN(duration) && calculateTime(duration)}
                  </div>
                </div>

                <div className="player-controls d-flex">
                  <div className="skip-btn" onClick={SkipSong}>
                    <SkipPreviousIcon />
                  </div>

                  <div className="skip-btn" onClick={backThirty}>
                    <Replay30Icon />
                  </div>

                  <div onClick={ChangePlayPause} className="play-btn">
                    {isPlaying ? (
                      <PauseCircleIcon fontSize="large" />
                    ) : (
                      <PlayCircleIcon fontSize="large" />
                    )}
                  </div>

                  <div className="skip-btn" onClick={forwardThirty}>
                    <Forward30Icon />
                  </div>

                  <div className="skip-btn" onClick={SkipSong}>
                    <SkipNextIcon />
                  </div>
                </div>

                <div className="player-settings d-flex">
                  <div className="skip-btn" onClick={() => changeSpeed()}>
                    {speed}x
                  </div>
                  <VolumeBtns />
                  <div className="skip-btn" onClick={FullScreen}>
                    <OpenInFullIcon />
                  </div>
                </div>
              </div>

              <div className="player-song-details d-flex">
                <div className="player-data">
                  <h3 className="details-title">{songs[songId].title}</h3>
                  <p className="details-Descp">{songs[songId].description}</p>
                </div>

                <div className="player-actions d-flex">
                  <div className="loved" onClick={changeSongLove}>
                    {isLove ? (
                      <FavoriteIcon fontSize="large" />
                    ) : (
                     
                      <FavoriteBorderIcon fontSize="large" />
                    )}
                  </div>
                  <SharePodcast song={songs[songId]} />
                </div>
              </div>
            </>
          ) : (
            <>
              <div className="footer-player-details">
                <div className="d-flex">
                  <img src={songs[songId].imgsrc} width="50" height="50" />
                  <div className="player-data">
                    <h3 className="details-title">{songs[songId].title}</h3>
                    <p className="details-Descp">{songs[songId].description}</p>
                  </div>
                </div>
                <div className="loved" onClick={changeSongLove}>
                  {isLove ? (
                     <FavoriteIcon fontSize="large" />
                  ) : (                  
                    <FavoriteBorderIcon fontSize="large" />
                  )}
                </div>
              </div>
            </>
          )}
        </div>

        {!slideUp && (
          <div className="footer-player-actions">
            <div onClick={ChangePlayPause} className="mini-play-btn">
              {isPlaying ? (
                <PauseCircleIcon fontSize="large" />
              ) : (
                <PlayCircleIcon fontSize="large" />
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
